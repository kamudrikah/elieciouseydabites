<ul class="nav navbar-nav collapse navbar-collapse">
	<li><a href="index.php">About Us</a></li>
	<li class="dropdown"><a href="#">Order<i class="fa fa-angle-down"></i></a>
  	<ul role="menu" class="sub-menu">
		<li><a href="promotion.php">Promotion</a></li>
		<li><a href="cake.php">Cake</a></li> 
		<li><a href="dessert.php">Dessert</a></li> 
		<li><a href="cookies.php">Cookies</a></li> 
		<li><a href="cup_cake.php">Cup Cakes</a></li> 
	</ul>
	<li><a href="receipt.php">Receipt Payment</a></li> 
	<li><a href="contact-us.php">Contact Us</a></li>
</ul>