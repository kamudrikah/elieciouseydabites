<head>
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

</head>

<li>
                                    <a href="#"><i class="fa fa-shopping-cart fa-fw"></i> Products<span class="fa arrow"></span></a>
                                    <ul class="nav nav-second-level">
                                      <li>
                                        <a href="addProduct.php"><i class="fa fa-edit fa-fw"></i> Add New Product </a>
                                      </li>
                                      <li>
                                        <a href="listProduct.php"><i class="fa fa-table fa-fw"></i> List Product</a>
                                      </li>
                                      <li>
                                        <a href="cod.php"><i class="fa fa-table fa-fw"></i> Add Cash On Delivery Places</a>
                                      </li>
                                    </ul>
                                    <!-- /.nav-second-level -->
                              </li> 