

<script language="javascript">
   alert('Registration Success!');
   window.location.href="../cust_signin.php";
</script>