

<script language="javascript">
   alert('Please Login!');
   window.location.href="http://elieciouseydabites.com/cust_signin.php";
</script>